'use client';

import React, { PointerEvent, useEffect, useMemo, useRef, useState } from 'react';
import styles from './letterTracing.module.css';
import { TRACE_LETTERS, TraceLetter } from './letters';

type Point = { x: number; y: number };

const SVG_W = 600;
const SVG_H = 520;
const HIT_RADIUS = 34;
const SAMPLE_STEP = 8;

function distance(a: Point, b: Point) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

export default function LetterTracingGame() {
  const title = 'Bé tập viết chữ';
  const letters: TraceLetter[] = TRACE_LETTERS;
  const initialLetterKey: string | undefined = undefined;
  const className: string | undefined = undefined;
  const firstIndex = Math.max(0, letters.findIndex((item) => item.key === initialLetterKey));
  const [letterIndex, setLetterIndex] = useState(firstIndex);
  const [score, setScore] = useState(0);
  const [message, setMessage] = useState('Tô theo nét mờ để hoàn thành chữ nhé!');
  const [isDrawing, setIsDrawing] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const boardRef = useRef<HTMLDivElement | null>(null);
  const pathRefs = useRef<(SVGPathElement | null)[]>([]);
  const samplePointsRef = useRef<Point[]>([]);
  const coveredRef = useRef<Set<number>>(new Set());
  const goodRef = useRef(0);
  const totalRef = useRef(0);
  const lastPointRef = useRef<Point | null>(null);

  const currentLetter = letters[letterIndex] ?? letters[0];

  const progressText = useMemo(() => {
    if (score >= 90) return 'Rất tốt! Bé viết rất sát nét.';
    if (score >= 70) return 'Tốt rồi! Bé tô thêm các đoạn còn thiếu nhé.';
    if (score > 0) return 'Đang luyện tốt, hãy đi chậm và bám vào nét mờ.';
    return message;
  }, [message, score]);

  function resizeCanvas() {
    const canvas = canvasRef.current;
    const board = boardRef.current;
    if (!canvas || !board) return;

    const rect = board.getBoundingClientRect();
    const ratio = window.devicePixelRatio || 1;
    canvas.width = Math.round(rect.width * ratio);
    canvas.height = Math.round(rect.height * ratio);
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(16, rect.width * 0.032);
    ctx.strokeStyle = '#ef7c43';
  }

  function clearCanvas() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  function rebuildSamples() {
    const points: Point[] = [];

    pathRefs.current.forEach((path) => {
      if (!path) return;
      const length = path.getTotalLength();
      for (let d = 0; d <= length; d += SAMPLE_STEP) {
        const p = path.getPointAtLength(d);
        points.push({ x: p.x, y: p.y });
      }
    });

    samplePointsRef.current = points;
    coveredRef.current = new Set();
    goodRef.current = 0;
    totalRef.current = 0;
    lastPointRef.current = null;
    setScore(0);
    setMessage('Tô theo nét mờ để hoàn thành chữ nhé!');
    clearCanvas();
  }

  useEffect(() => {
    resizeCanvas();
    const t = window.setTimeout(rebuildSamples, 80);
    window.addEventListener('resize', resizeCanvas);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener('resize', resizeCanvas);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [letterIndex]);

  function getSvgPoint(event: PointerEvent<HTMLCanvasElement>): Point {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((event.clientX - rect.left) / rect.width) * SVG_W,
      y: ((event.clientY - rect.top) / rect.height) * SVG_H
    };
  }

  function getCanvasPoint(svgPoint: Point): Point {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (svgPoint.x / SVG_W) * rect.width,
      y: (svgPoint.y / SVG_H) * rect.height
    };
  }

  function nearestDistance(point: Point) {
    const samples = samplePointsRef.current;
    let best = Infinity;
    let bestIndex = -1;

    for (let i = 0; i < samples.length; i += 1) {
      const d = distance(point, samples[i]);
      if (d < best) {
        best = d;
        bestIndex = i;
      }
    }
    return { best, bestIndex };
  }

  function updateCoverage(point: Point) {
    const samples = samplePointsRef.current;
    const { best, bestIndex } = nearestDistance(point);
    totalRef.current += 1;

    if (best <= HIT_RADIUS) {
      goodRef.current += 1;
      const coverRange = 4;
      for (let i = bestIndex - coverRange; i <= bestIndex + coverRange; i += 1) {
        if (i >= 0 && i < samples.length) coveredRef.current.add(i);
      }
    }

    const accuracy = totalRef.current ? goodRef.current / totalRef.current : 0;
    const coverage = samples.length ? coveredRef.current.size / samples.length : 0;
    const nextScore = Math.round(clamp((accuracy * 0.48 + coverage * 0.52) * 100, 0, 100));
    setScore(nextScore);

    if (nextScore >= 90) setMessage('Hoàn thành rất đẹp!');
    else if (best > HIT_RADIUS) setMessage('Đi chậm lại và bám sát nét mờ hơn nhé.');
    else setMessage('Tốt rồi, tô tiếp cho đủ nét nhé!');
  }

  function drawTo(point: Point) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const canvasPoint = getCanvasPoint(point);
    const last = lastPointRef.current ? getCanvasPoint(lastPointRef.current) : canvasPoint;
    ctx.beginPath();
    ctx.moveTo(last.x, last.y);
    ctx.lineTo(canvasPoint.x, canvasPoint.y);
    ctx.stroke();
    lastPointRef.current = point;

    updateCoverage(point);
  }

  function handlePointerDown(event: PointerEvent<HTMLCanvasElement>) {
    event.currentTarget.setPointerCapture(event.pointerId);
    setIsDrawing(true);
    const point = getSvgPoint(event);
    lastPointRef.current = point;
    drawTo(point);
  }

  function handlePointerMove(event: PointerEvent<HTMLCanvasElement>) {
    if (!isDrawing) return;
    drawTo(getSvgPoint(event));
  }

  function stopDrawing(event: PointerEvent<HTMLCanvasElement>) {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
    setIsDrawing(false);
    lastPointRef.current = null;
  }

  function reset() {
    coveredRef.current = new Set();
    goodRef.current = 0;
    totalRef.current = 0;
    lastPointRef.current = null;
    setScore(0);
    setMessage('Tô theo nét mờ để hoàn thành chữ nhé!');
    clearCanvas();
  }

  function nextLetter() {
    setLetterIndex((value) => (value + 1) % letters.length);
  }

  function speak() {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(currentLetter.speak);
    utterance.lang = 'vi-VN';
    utterance.rate = 0.82;
    window.speechSynthesis.speak(utterance);
  }

  return (
    <section className={`${styles.module} ${className ?? ''}`}>
      <div className={styles.header}>
        <div>
          <p className={styles.eyebrow}>Game luyện viết</p>
          <h2>{title}</h2>
        </div>
        <div className={styles.scoreBox}>
          <span>{score}</span>
          <small>điểm</small>
        </div>
      </div>

      <div className={styles.letterList} aria-label="Chọn chữ">
        {letters.map((item, index) => (
          <button
            type="button"
            key={item.key}
            className={index === letterIndex ? styles.activeLetter : ''}
            onClick={() => setLetterIndex(index)}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className={styles.boardWrap}>
        <div className={styles.board} ref={boardRef}>
          <div className={styles.grid} />

          <svg className={styles.svgLayer} viewBox={`0 0 ${SVG_W} ${SVG_H}`} aria-hidden="true">
            {currentLetter.paths.map((path, index) => (
              <path
                key={`${currentLetter.key}-${index}`}
                ref={(node) => {
                  pathRefs.current[index] = node;
                }}
                d={path}
                className={styles.tracePath}
              />
            ))}
          </svg>

          <canvas
            ref={canvasRef}
            className={styles.canvas}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={stopDrawing}
            onPointerCancel={stopDrawing}
            aria-label={`Bảng tô ${currentLetter.speak}`}
          />
        </div>
      </div>

      <div className={styles.status}>
        <div className={styles.progressTrack}>
          <div className={styles.progressBar} style={{ width: `${score}%` }} />
        </div>
        <p>{progressText}</p>
      </div>

      <div className={styles.actions}>
        <button type="button" onClick={speak}>Nghe chữ</button>
        <button type="button" onClick={reset}>Làm lại</button>
        <button type="button" onClick={nextLetter}>Chữ tiếp theo</button>
      </div>
    </section>
  );
}
