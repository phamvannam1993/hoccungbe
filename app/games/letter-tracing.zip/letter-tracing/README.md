# Letter Tracing Game

Thư mục này được thiết kế để copy thẳng vào project Next.js App Router.

## Cách dùng

Copy nguyên thư mục `letter-tracing` vào:

```txt
src/app/games/letter-tracing
```

Sau đó chạy project và mở:

```txt
/games/letter-tracing
```

## Cấu trúc

```txt
letter-tracing/
├─ page.tsx
├─ letters.ts
├─ letterTracing.module.css
└─ README.md
```

## Mở rộng chữ mới

Mở file `letters.ts`, thêm object mới vào mảng `TRACE_LETTERS`.
Mỗi chữ dùng hệ tọa độ SVG 600x520 và có thể có nhiều `paths` cho nhiều nét rời.
