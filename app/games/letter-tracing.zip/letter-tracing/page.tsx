import type { Metadata } from 'next';
import GameStructuredData from '@/app/components/edu/GameStructuredData';
import LetterTracingGame from './LetterTracingGame';

export const metadata: Metadata = {
  title: 'Tập Viết Chữ - Trò Chơi Luyện Viết Cho Bé | Bé Hay Học',
  description:
    'Trò chơi luyện viết chữ với 58 chữ cái (A-Z, ă, â, ê, ô, ơ, ư, đ). Bé học viết chữ đẹp qua tương tác vẽ theo nét mờ. Có phát âm tiếng Việt.',
  keywords: [
    'tập viết chữ',
    'luyện viết',
    'dạy trẻ viết chữ',
    'trò chơi viết chữ',
    'học chữ cái',
    'phát triển kỹ năng viết',
    'giáo dục trẻ em',
    'tiếng Việt cho bé',
  ],
  alternates: {
    canonical: 'https://behayhoc.com/tro-choi/tap-viet-chu',
  },
  openGraph: {
    title: 'Tập Viết Chữ - Trò Chơi Luyện Viết Cho Bé',
    description: 'Trò chơi luyện viết chữ giúp bé phát triển kỹ năng viết và nhận diện chữ cái',
    url: '/tro-choi/tap-viet-chu',
    type: 'website',
    images: [
      {
        url: 'https://behayhoc.com/og-letter-tracing.jpg',
        width: 1200,
        height: 630,
        alt: 'Trò chơi tập viết chữ cho bé',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Tập Viết Chữ - Bé Hay Học',
    description: 'Trò chơi luyện viết chữ giúp bé học viết chữ đẹp',
    images: ['https://behayhoc.com/og-letter-tracing.jpg'],
  },
};

export default function LetterTracingPage() {
  return (
    <>
      <GameStructuredData slug="tap-viet-chu" />
      <LetterTracingGame />
    </>
  );
}
